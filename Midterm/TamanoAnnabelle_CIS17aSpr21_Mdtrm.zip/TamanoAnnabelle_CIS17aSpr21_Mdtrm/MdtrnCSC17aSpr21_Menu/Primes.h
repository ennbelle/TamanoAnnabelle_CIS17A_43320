/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Primes.h
 * Author: annat
 *
 * Created on April 29, 2021, 11:12 PM
 */

#ifndef PRIMES_H
#define PRIMES_H

struct Primes {
    unsigned char nPrimes;
    Prime prime[100];
};


#endif /* PRIMES_H */

