var searchData=
[
  ['badbet_0',['BadBet',['../class_gen_plyr_1_1_bad_bet.html',1,'GenPlyr']]]
];
